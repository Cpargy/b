# sol2041-sum21
Lab Set Solutions for CSci 2041, Summer 2021
