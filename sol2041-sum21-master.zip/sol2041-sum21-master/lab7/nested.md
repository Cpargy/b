# `nmem x nl ≡ mem x (flatten nl)`

### Property
P(l): &forall; x . `nmem x l ≡ mem x (flatten l)`

### Base Case
P(Nil): &forall; x . `nmem x Nil ≡ mem x (flatten Nil)`

We have:
+ `nmem x Nil` ≡ false, ***[eval of `nmem`]***
+ ≡ `mem x []` ***[reverse eval of `mem`]***
+ ≡ `mem (flatten Nil)` ***[reverse eval of `flatten`]***, &check;

### Inductive Case
&forall; nl . [&forall x. `nmem x nl ≡ mem x (flatten nl)`] &rArr; [&forall; x . &forall; y. `nmem x (Cons (y,nl)) ≡ mem x (flatten (Cons(y,nl)))`]

#### IH: &forall; x . `nmem x nl ≡ mem x (flatten nl)`

Let `y` be an arbitrary element of type 'a, then we need to show that `nmem x (Cons(y,nl)) ≡ mem x (flatten (Cons (y,nl)))`:
+ `nmem x (Cons (y,nl))` ≡ `(y≡x) || (nmem x nl)` ***[eval of `nmem`]***
+ ≡ `(y≡x) || mem x (flatten nl)` ***[by IH]***
+ ≡ `mem x (y::(flatten nl))` ***[reverse eval of mem]***
+ ≡ `mem x (flatten (Cons (y,nl)))` ***[reverse eval of `flatten`]***, &check;

### Inductive Case
&forall; n1 &forall; n2 . [&forall; x `nmem x n1 ≡ mem x (flatten n1)` && `nmem x n2 ≡ mem x (flatten l2)`] &rArr; [&forall; x . `nmem x (Nest (n1,n2)) ≡ mem x (flatten (Nest(n1,n2)))`].

#### IH: `nmem x n1 ≡ mem x (flatten n1)` && `nmem x n2 ≡ mem x (flatten n2)`

We need to show that `nmem x (Nest(n1,n2)) ≡ mem x (flatten (Nest(n1,n2)))`:
+ `nmem x (Nest (n1,n2))` ≡ `(nmem x n1) || (nmem x n2)` ***[eval of `nmem`]***
+ ≡ `(mem x (flatten n1)) || (mem x (flatten n2))` ***[by IH]***
+ ≡ `mem x ((flatten n1) @ (flatten n2))` ***[`mem`/`append` identity]***
+ ≡ `mem x (flatten (Nest(n1,n2)))` ***[reverse eval of `flatten`]***, &check;
