# `tr_nat`

### Property
P(`m`): ∀ 𝓃 : ℕ  . `tr_nat 𝓃 m` ≡ `𝓃 + (to_int m)`

### Base Case
P(`Zero`): ∀ 𝓃 : ℕ . `tr_nat 𝓃 Zero` ≡ `𝓃 + (to_int Zero)`

We have:
`tr_nat 𝓃 Zero` ≡ `𝓃` **[eval of `tr_nat`]**

≡ `𝓃 + 0` **[simplification]**

≡ `𝓃 + (to_int Zero)` **[reverse eval of `to_int`]**

### Inductive Case
∀ `m` . [ ∀ 𝓃 . `tr_nat 𝓃 m` ≡ `𝓃 + (to_int m)` ] ⇒ [ ∀ 𝓃 . `tr_nat 𝓃 (Succ m)` ≡ `𝓃 + (to_int (Succ m))` ]

#### IH: ∀ 𝓃 .`tr_nat 𝓃 m` ≡ `𝓃 + (to_int m)`

We need to show that ∀ 𝓃 . `tr_nat 𝓃 (Succ m)` ≡ `𝓃 + (to_int (Succ m))`.  We have:

`tr_nat 𝓃 (Succ m)` ≡ `tr_nat (𝓃+1) m` **[eval of `tr_nat`]**

≡ `(𝓃+1) + (to_int m)` **[by IH]**

≡ `𝓃 + (1 + (to_int m))` **[simplification]**

≡ `𝓃 + (to_int (Succ m))` **[reverse eval of `to_int`]**, ✓
