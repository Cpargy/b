# `length (append l1 l2) = (length l1) + (length l2)`

### Property
P(l): ∀ l2 . `length (append l l2) = (length l) + (length l2)`

### Base Case
P([]): ∀ l2 . `length (append [] l2) = (length []) + (length l2)`

We have
+ `length (append [] l2)` = `length l2` ***[eval of `append`]***
+ = `0 + (length l2)` ***[arith]***
+ = `(length []) + (length l2)` ***[reverse eval of `length`]***, ✓

### Inductive Case
∀ l . [∀ l2 . `length (append l l2) = (length l) + (length l2)`] ⇒ [ ∀ h . ∀ l2. `length (append (h::l) l2) = (length (h::l)) + (length l2)` ]

#### IH: ∀ l2. `length (append l l2) = (length l) + (length l2)`
Let `h : t` be an arbitrary element and l2 an arbitrary `t list`, then we want to show that `length (append (h::l) l2) = (length (h::l)) + (length l2)`:

+ `length (append (h::l) l2)` = `length (h::(append l l2))` ***[eval of `append`]***
+ = `1 + (length (append l l2))` ***[eval of `length`]***
+ = `1 + (length l) + (length l2)` ***[by IH]***
+ = `(length (h::l)) + (length l2)` ***[reverse eval of `length`]***, ✓
