# `tr_sum`

### Property
P(n): ∀ 𝒶 : ℕ . `tr_sum n 𝒶` ≡ `𝒶 + (sumup n)`

### Base Case
P(0): ∀ 𝒶 `tr_sum 0 𝒶` ≡ `𝒶 + (sumup 0)`

We have:

`tr_sum 0 𝒶` ≡ `𝒶` **[eval of `tr_sum`]**

≡ `0 + 𝒶` **[algebra]**

≡ `(sumup 0) + 𝒶` **[reverse eval `sumup`]**, ✓

### Inductive Case
∀ 𝓃 . [ ∀ 𝒶 . `tr_sum 𝓃 𝒶` ≡ `𝒶 + (sumup 𝓃)` ] ⇒ [ ∀ 𝒶 . `tr_sum (𝓃+1) 𝒶` ≡ `𝒶 + (sumup (𝓃+1)) ` ]

#### IH: ∀ 𝒶 . `tr_sum n 𝒶` ≡ `𝒶 + (sumup n)`

We need to prove that ∀ 𝒶 . `tr_sum (n+1) 𝒶` ≡ `𝒶 + (sumup (n+1))`.
We have:

`tr_sum (n+1) 𝒶` ≡ `tr_sum n ((n+1)+𝒶)` **[eval of `tr_fact`]**

≡ `((n+1)+𝒶) + (sumup n)` **[by IH]**

≡ `𝒶 + ((n+1) + (sumup n)` **[algebra]**

≡ `𝒶 + (sumup (n+1))` **[reverse eval. `sumup`]**, ✓
