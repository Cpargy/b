# `eq_nat`

We have the following definitions:

```
type nat = Zero | Succ of nat

let rec to_int = function Zero -> 0
| Succ m -> 1 + (to_int m)

let rec eq_nat n1 n2 = match (n1,n2) with
| (Zero,Zero) -> true
| (Zero,_) | (_, Zero) -> false
| (Succ n1', Succ n2') -> eq_nat n1' n2'
```

And are asked to prove that ∀ `m, n : nat`, `(eq_nat m n)` ≡ `(to_int m) = (to_int n)`.

We define the property `P(n)`: ∀`m : nat`, `(eq_nat m n)` ≡ `(to_int m) = (to_int n)`.

### Base Case:
`P(Zero)`: ∀`m : nat`, `(eq_nat m Zero)` ≡ `(to_int m) = (to_int Zero)`.
We consider two cases for `m`:
    + `m = Zero`: then `eq_nat m Zero ≡ true`, and `(to_int m = to_int Zero) ≡ true`, ✓
    + `m = Succ m'` then `eq_nat m Zero ≡ false`, and `(to_int m = to_int Zero)  ≡ (1 + (to_int m') = 0) ≡ false`, ✓

### Inductive Case:
We want to show that for all `n`, `P(n) ⇒ P(Succ n)`.  Thus we make the following

#### IH: ∀`m`, `eq_nat m n ≡ ((to_int m) = (to_int n))`.

We want to show that `eq_nat m (Succ n) ≡ ((to_int m) = (to_int (Succ n)))`.

We again consider two cases for `m`:

    + `m = Zero`: then `eq_nat m (Succ n) ≡ eq_nat Zero (Succ n) ≡ false`,
    and `((to_int m) = (to_int (Succ n))) ≡ (0 = 1 + (to_int n)) ≡ false`, ✓

    + `m = Succ m'`, then
    `eq_nat m (Succ n) ≡ eq_nat (Succ m') (Succ n)` **[definition of `m`]**
    `≡ eq_nat m' n` **[eval of `eq_nat`]**
    `≡ (to_int m' = to_int n)` **[by IH]**
    `≡ (1 + (to_int m') = 1 + (to_int n))` **[arith]**
    `≡ (to_int (Succ m') = to_int (Succ n))` **[reverse eval of `to_int`]**
    `≡ (to_int m = to_int (Succ n))` **[definition of `m`]**, ✓
