# `mem e (reverse l) ≡ mem e l`

### Property
P(l): ∀ e . `mem e (reverse l) ≡ mem e  l`

### Base Case
P([]): ∀ e . `length (reverse []) ≡ (length [])`

We have

+ `mem e (reverse [])` ≡ `mem e []` ***[eval of `reverse`]***, ✓

### Inductive Case
∀ l . [∀ e. `mem e (reverse l) ≡ (mem e l)`] ⇒ [ ∀ h . ∀ e. `mem e (reverse (h::l)) ≡ (mem e (h::l))` ]

#### IH: ∀ e. `mem e (reverse l) ≡ (mem e l)`
Let `h` be an arbitrary element, then we want to show that `mem e (reverse (h::l)) ≡ (mem e (h::l))`:

+ `mem e (reverse (h::l))` ≡ `mem e (append (reverse l) [h])` ***[eval of `reverse`]***
+ ≡ `(mem e (reverse l)) || (mem e [h])` ***[mem(append) thm.]***
+ ≡ `(mem e l) || (mem e [h])` ***[by IH]***
+ ≡ `(mem e l) || e=h` ***[2x eval of `mem`]***
+ ≡ `e=h || (mem e l)` ***[boolean algebra]***
+ ≡ `(mem e (h::l))` ***[reverse eval of `mem`]***, ✓
