# `size t ≡ size (mirror t)`

### Property
P(`t`): `size t ≡ size (mirror t)`
### Base Case
P(`Empty`): `size Empty ≡ size (mirror Empty)`

We have

+ `size (mirror Empty)` ≡ `size (Empty)` ***[eval of `mirror`]***, &check;

### Inductive Case
&forall; t1 . &forall; t2. [`size t1 ≡ size (mirror t1)` && `size t2 ≡ size (mirror t2)`] &rArr; [&forall; v . `size (Node (v,t1,t2)) ≡ size (mirror (Node (v,t1,t2)))`]


#### IH: `size t1 ≡ size (mirror t1)` && `size t2 ≡ size (mirror t2)`

Let v be an arbitrary element of type 'a, then we want to show that `size (Node (v,t1,t2)) ≡ size (mirror (Node (v,t1,t2)))`:

+ `size (Node (v,t1,t2))` ≡ `1 + (size t1) + (size t2)` ***[eval of `size`]***
+ ≡ `1 + (size (mirror t1)) + (size (mirror t2))` ***[by IH]***
+ ≡ `1 + (size (mirror t2)) + (size (mirror t1))` ***[arith]***
+ ≡ `size (Node (v,mirror t2, mirror t1))` ***[reverse eval of `size`]***
+ ≡ `size (mirror (Node (v,t1,t2)))` ***[reverse eval of `mirror`]***, &check;
