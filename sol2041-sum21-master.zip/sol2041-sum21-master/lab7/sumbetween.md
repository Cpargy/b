# `sumbetween`

### Property
P(n): ∀ `m : ℕ`, `m ≤ n` ⇒ `sumbetween m n` ≡ `(sumup n) - (sumup m)`

### Base Case:
P(0): ∀ `m : ℕ`, `m ≤ 0` ⇒ `sumbetween m 0` ≡ `(sumup 0) - (sumup m)`

We have:

`sumbetween m 0` ≡ `0` **[ eval. `sumbetween` with `m ≤ 0` ]**

≡ `0 - 0` **[algebra]**

≡ `(sumup 0) - 0` **[reverse eval `sumup`]**

≡ `(sumup 0) - (sumup m)` **[reverse eval `sumup` with `m ≤ 0`]**

### Inductive Case
∀ 𝓃 . [∀ m, m ≤ 𝓃 ⇒ `sumbetween m 𝓃` ≡ `(sumup 𝓃) - (sumup m)`] ⇒ [∀ m, m ≤ (𝓃+1) ⇒ `sumbetween m (𝓃+1)` ≡ `(sumup (𝓃+1) - (sumup m)`]

#### IH: ∀ m, m ≤ n ⇒ `sumbetween m n` ≡ `(sumup n) - (sumup m)`
We want to prove:
`m ≤ (n+1)` ⇒ `sumbetween m (n+1)` ≡ `(sumup (n+1)) - (sumup m)`

We consider two cases for `m`:

1. `m = n+1`. Then:

  `sumbetween m (n+1)` ≡ `0` **[eval `sumbetween` with `m = (n+1)`]**

  ≡ `(sumup (n+1)) - (sumup (n+1))` **[algebra]**

  ≡ `(sumup (n+1)) - (sumup m)` **[since `m = (n+1)`]**, ✓

2. `m ≤ n`.  Then:

  `sumbetween m (n+1)` ≡ `(n+1) + (sumbetween m n)` **[eval `sumbetween` with `m < (n+1)`]**

  ≡ `n+1 + ((sumup n) - (sumup m))` **[IH]**

  ≡ `((n+1) + (sumup n)) - (sumup m)` **[algebra]**

  ≡ `(sumup (n+1)) - (sumup m)` **[reverse eval `sumup`]**, ✓

Since these are the only cases where `m ≤ n+1`, the IH implies the IC in all cases.
