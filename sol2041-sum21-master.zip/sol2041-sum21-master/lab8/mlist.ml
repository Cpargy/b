(* linked list type *)
type 'a ll = { mutable hd : 'a ; mutable tl : 'a mlist}
 and 'a mlist = List of 'a ll | Nil

let rec list_of_mlist ml = match ml with
| Nil -> []
| List mc -> mc.hd :: (list_of_mlist mc.tl)


(* tail recursive version *)
let tr_mlist_of_list ls =
  let rec add_next ls fst prev = match ls with
  | [] -> fst
  | h::t -> let nl = {hd=h; tl=Nil} in
      prev.tl <- List nl; add_next t fst nl
  in match ls with [] -> Nil
  | h::t -> let hh = {hd=h; tl=Nil} in add_next t (List hh) hh

(* plain recursive version *)
let rec mlist_of_list ls = match ls with
| [] -> Nil
| h::t -> List {hd=h; tl=(mlist_of_list t)}

let rev_mlist lst =
  let ch = ref Nil in
  let rec revver p = match p with Nil -> !ch
  | List nxt -> let nn = nxt.tl in nxt.tl <- !ch ; ch := List nxt ; revver nn
  in revver lst

let append_m l1 l2 = match l1 with
| Nil -> l2
| List {hd = h; tl = t} ->
  let rec app_m l = match l with Nil -> failwith "append_m"
  | List ({hd = h; tl = Nil} as last) -> last.tl <- l2
  | List nl -> app_m nl.tl in app_m l1 ; l1

(* Modify the list ml to insert b after the first occurence of a *)
let rec insert_after_m a b ml = match ml with
| Nil -> raise Not_found
| List mc -> if mc.hd = a then mc.tl <- List {hd=b; tl=mc.tl}
            else insert_after_m a b mc.tl


(* Modify the list ml to exclude all items that satisfy the predicate p *)
let rec exclude_m p ml = match ml with
| Nil -> Nil
| List mc -> if (p mc.hd) then exclude_m p mc.tl
            else begin mc.tl <- exclude_m p mc.tl; (List mc) end
