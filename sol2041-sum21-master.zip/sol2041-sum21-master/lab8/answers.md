# Question 3 - record your answers with one space after each numbered bullet below:

1. I think my favorite is lazy evaluation, streams and other infinite data structures are just really neat!

2. Well, I like them all, but I'll look forward to seeing your suggestions.

3. I hope you enjoyed it, and scheduled a single project instead of multiple to try to decrease the weekly churn rate of the course.
