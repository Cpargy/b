type 'a clist = Nil | CCons of 'a * 'a clist ref
let chd = function Nil -> invalid_arg "chd" | CCons(h,_) -> h
let ctl = function Nil -> invalid_arg "ctl" | CCons(_,t) -> !t

let rec clist_of_list ls = match ls with
| [] -> Nil
| h::t -> CCons(h, ref (clist_of_list t))

let findcycle cl = 
let rec th t h = if t==h then true else match (t, h) with
|(_, Nil) -> false
| (CCons(_,tt),CCons(hh,ht)) -> match (!ht) with Nil -> false
    | CCons (hth,htt) -> th !tt !htt in
match cl with Nil -> false | CCons (h,t) -> th cl !t;;

let make_cyclic cl = 
  let rec findtail h t = match t with
  | Nil -> invalid_arg "makecycle"
  | CCons(th,tt) -> if (!tt = Nil) then tt := h else findtail h !tt
  in findtail cl cl
