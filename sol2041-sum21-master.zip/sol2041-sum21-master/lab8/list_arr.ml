let rev_array a =
  let rec revarray l u = if (u<=l) then ()
    else let swp = a.(u) in
      a.(u) <- a.(l) ; a.(l) <- swp ; revarray (l+1) (u-1)
  in revarray 0 ((Array.length a) - 1)

let zip_array u v =
  if (Array.length u) <> (Array.length v) then
    invalid_arg "zip_array"
  else Array.map2 (fun ui vi -> (ui,vi)) u v
