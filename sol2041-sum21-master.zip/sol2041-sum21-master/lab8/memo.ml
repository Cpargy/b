(* memo.ml - memoization with references *)

let rec pell n = match n with
| 0 -> 0
| 1 -> 1
| _ -> 2*(pell (n-1)) + (pell (n-2))

let rec alt4 n = match n with
| 0 -> 3
| 1 -> 1
| 2 -> 4
| 3 -> 2
| _ -> 1*(alt4 (n-1)) - (4 * (alt4 (n-2))) + (alt4 (n-3)) - (4 * (alt4 (n-4)))


let memopell =
  let ptable = ref [] in
  let rec mpell n = match n with
  | 0 -> 0
  | 1 -> 1
  | _ -> try List.assoc n !ptable with
    Not_found -> let pn = 2*(mpell (n-1)) + (mpell (n-2)) in ptable := (n,pn)::!ptable; pn
in mpell;;

let memoalt4 =
  let atable = ref [] in
  let rec ma4 n = match n with
  | 0 -> 3
  | 1 -> 1
  | 2 -> 4
  | 3 -> 2
  | _ -> try List.assoc n !atable with
    Not_found -> let a4n = (ma4 (n-1)) - (4 * (ma4 (n-2))) + (ma4 (n-3)) - (4 * (ma4 (n-4)))
      in atable := (n,a4n)::!atable; a4n
in ma4;;
