(* data type to represent an infinite data object in a "lazy" fashion *)
type 'a stream = Cons of 'a * (unit -> 'a stream)
| End


(* Some utility functions for streams *)
let hd (Cons(h,t)) = h
let tl (Cons(h,t)) = t ()

let rec take_s n s = match (n,s) with
| (0,_) | (_,End) -> []
| (_,Cons(h,t)) -> h::(take_s (n-1) (t ()))

let rec merge s1 s2 = match (s1,s2) with
| (End, _) -> s2
| (_, End) -> s1
| _ -> Cons(hd s1, fun () -> Cons(hd s2, fun () -> merge (tl s1) (tl s2)))

let rec filter_s p = function
| End -> End
| Cons(h,t) -> if (p h) then Cons(h, fun () -> filter_s p (t ()))
  else filter_s p (t ())

let double s = merge s s

(* Some streams we have seen in lecture *)
let rec nats n = Cons(n, fun () -> nats (n+1))
let fibs = let rec fib_help f0 f1 = Cons(f0, fun () -> fib_help f1 (f0+f1))
	in fib_help 0 1
let factorials = let rec fact_help n a = Cons(n*a, fun () -> fact_help (n+1) (n*a))
	in fact_help 1 1

let rec repeating s = Cons(s, fun () -> repeating s)
(* Your solutions go here: *)

let rec map_s (f : 'a -> 'b) (s : 'a stream) = match s with
| End -> End
| Cons(h,t) -> Cons((f h), fun () -> map_s f (t ()))

let rec odds_s (s : 'a stream) = match s with
| End -> End
| Cons(_,t) -> evens_s (t ())
and evens_s s = match s with
| End -> End
| Cons(h,t) -> Cons(h, fun () -> odds_s (t ()))

(* Or another way: *)
let odds_s s =
        let rec odsh s b = match (s,b) with
        | (End,_) -> End
        | (Cons(h,t),false) -> odsh (t ()) true
        | (Cons(h,t),true) -> Cons(h, fun () -> odsh (t ()) false)
        in odsh s false

(* or a third way: *)
let odds_s s = match s with
| End -> End
| Cons(_,t) -> match (t ()) with End -> End 
               | Cons(h,tt) -> Cons(h, fun () -> odds_s (tt ()))

let rec natpairs ((m,n) : int * int) =
  Cons((m,n), fun () -> if (n=0) then natpairs (0,m+1) else natpairs (m+1,n-1))

let pal_check s =
  let ss = String.uppercase s in
  let n = (String.length s)-1 in
  let rec pal_it i =
    if i = 0 then ss.[0] = ss.[n]
    else ss.[i] = ss.[n-i] && pal_it (i-1) in
  if s="" then true else pal_it n


let rec bstrings_s (s1 : string) (s2 : string) =
  let rec bstr s = Cons(s, fun () -> merge (bstr (s1^s)) (bstr (s2^s)))
  in bstr ""

let  palindromes (s1 : string) (s2 : string) = filter_s pal_check (bstrings_s s1 s2)
