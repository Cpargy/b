1. `take 2 (squares 3)`
Normal Form
[9; 16]
The full evaluation is:
```ocaml
take 2 9::(squares 4)
9::(take 1 (squares 4))
9::(take 1 16::(squares 5))
9::16::(take 0 (squares 5))
9::16::[]
```

2. `fold_right (&&) (map ((<) 0) (squares 2)) true`
Never
The evaluation starts:
```ocaml
fold_right (&&) (map ((<) 0) 4::(squares 3)) true
fold_right (&&) (((<) 0) 4)::(map ((<) 0) (squares 3)) true
fold_right (&&) true::(map ((<) 0) (squares 3)) true
(&&) true (fold_right (&&) (map ((<) 0) (squares 3)) true)
```
And since squares will never return `[]`, `map` will never return `[]`, and all elements of the list will evaluate to true, so we can never short-circuit evaluation.

3. `fold_right (||)  (map (fun n -> n mod 3 = 0) (factorials ())) false`
Normal Form
true
The third element of `(factorials ())` will be 6, and `(6 mod 3 = 0)` is true, allowing the short-circuit `||` to return true.

4. `take (sum_list (squares 1)) (factorials ())`
Never
`(squares n)` never evaluates to `[]`, so `sum_list` can never terminate; thus `(take (sum_list (squares 1)))` can never terminate evaluation.

5. `take 1 (reverse (squares 2))`
Never
`(squares n)` never evaluates to `[]`, so reverse can never terminate evaluation.  

6. `fold_right (+) (take 1 (factorials ())) 0`
Normal Form
1
The full evaluation is:
```ocaml
fold_right (+) (take 1 (fac_acc 1 1)) 0
fold_right (+) (take 1 1::(fac_acc 2 1)) 0
fold_right (+) 1::(take 0 (fac_acc 2 1)) 0
(+) 1 (fold_right (+) (take 0 (fac_acc 2 1)) 0)
(+) 1 (fold_right (+) [] 0)
(+) 1 0
1
```

7. `(fun x -> if false then x else ()) (flip 0 0)`
Normal Form
()
The full evaluation is:
```ocaml
if false then (flip 0 0) else ()
()
```
(because `if` has conditional evaluation)
