For the explanation, write the step-by-step lazy evaluation of each of the following _`lazyCaml`_ expressions; or if the expression does not terminate with a normal form, state why:

1. `treefind (crazytree 1 "?") "abuffalo?"`
Normal Form
true
```
treefind (crazytree 1 "?") "abuffalo?"
treefind (Node (crazytree 0 "a?"), crazytree 1 "buffalo?")) "abuffalo?"
(treefind (crazytree 0 "a?") "abuffalo?") || (treefind (crazytree 1 "buffalo?") "abuffalo?")
(treefind (Leaf "a?") "abuffalo?") || (treefind (crazytree 1 "buffalo?") "abuffalo?")
false || (treefind (crazytree 1 "buffalo?") "abuffalo?")
(treefind (crazytree 1 "buffalo?") "abuffalo?")
(treefind (Node (crazytree 0 "abuffalo?", crazytree 1 "buffaloabuffalo?")), "abuffalo?")
(treefind (crazytree 0 "abuffalo?") "abuffalo?") || (treefind (crazytree 1 "buffaloabuffalo?") "abuffalo?")
(treefind (Leaf "abuffalo?") "abuffalo?") || (treefind (crazytree 1 "buffaloabuffalo?") "abuffalo?")
true || (treefind (crazytree 1 "buffaloabuffalo?") "abuffalo?")
true

2. `treefind (crazytree 1 "!") "buffalobuffalo!"`
Never
All of the leaf values created by `crazytree` start with `'a'`, so we'll never find a string starting with `'b'`.

3. `let rec it1 = Node (it1, Leaf 4) in let rec it2 = Node (Leaf 3, it2) in eqtree it1 it2`
Normal Form
false
```
eqtree (Node (it1, Leaf 4)) (Node (Leaf 3), it2)
(eqtree (Leaf 4) it2) && (eqtree it1 (Leaf 3))
false && (eqtree it1 (Leaf 3))
false
```

4. `let rec it4 = Node (it4, Leaf 4) in let rec it3 = Node(it3, Leaf 4) in eqtree it3 it4`
Never
Evaluation cycles infinitely:
```
eqtree it3 it4
eqtree (Node (it3, Leaf 4)) (Node (it4, Leaf 4))
(eqtree (Leaf 4) (Leaf 4)) && (eqtree it3 it4)
true && (eqtree it3 it4)
eqtree it3 it4
``` 
