# short1.py
# print("hello world!") # so you know it's python3
x = 4*3
