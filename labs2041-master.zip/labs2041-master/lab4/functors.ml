(* lab4 part 3 *)
