(* exn.ml - skeleton for lab exercise 4.1 *)

let reflector x = (* fill it in *)
let catcher r x = (* this one too *)

let make_opt f e = raise e (* not right *)

let rec safe_substr s b l = "" (* not right *)

let rec rm_assoc_exit k lst = [] (* fix this *)

let rm_assoc k lst = try rm_assoc_exit k lst with Exit -> lst
