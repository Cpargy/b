let rev_array a = ()

let zip_array u v = [||]
