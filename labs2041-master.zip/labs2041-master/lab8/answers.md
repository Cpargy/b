# Question 3 - record your answers with one space after each numbered bullet below:

1.

2.

3.
