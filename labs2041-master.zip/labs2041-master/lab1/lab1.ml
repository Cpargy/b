(* OCaml file for lab 1.
   Fix the errors in this file.  *)

let zero = (-2 + )

let fun x = x
let begin s = s.[zero]
let len val = String.length val
  
let mult x = x * y

let or3 a b c = x || y || z

let helloworld = "hello" + "world"

let ending s t = let last = len s - 1 in String.sub s last - t t  

let c = beginning ""
	       
let () = print_string (ending "Looks like we made it!\n" 9)
  
