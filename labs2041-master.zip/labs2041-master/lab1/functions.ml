(* functions.ml -- add your definitions for the functions in lab1 part 2 here *)
