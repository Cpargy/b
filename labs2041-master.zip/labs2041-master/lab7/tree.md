# `tree`

### Property
P(t):

### Base Case
P(Empty):

### Inductive Case

#### IH: 
