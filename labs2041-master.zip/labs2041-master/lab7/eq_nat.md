# `eq_nat`

### Property
`P(n)`:

### Base Case:
`P(Zero)`:

### Inductive Case:

#### IH: 
