# `nested`

### Property
P(nl):

### Base Case
P(Nil):

### Inductive Cases

#### IH: 
