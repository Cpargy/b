# `tr_nat`

### Property
P(`m`):

### Base Case
P(`Zero`):

### Inductive Case

#### IH: 
