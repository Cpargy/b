# `sumbetween`

### Property
P(n):

### Base Case:
P(0):

### Inductive Case

#### IH: 
