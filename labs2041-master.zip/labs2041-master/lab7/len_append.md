# `length (append l1 l2) = (length l1) + (length l2)`

### Property
P(l):

### Base Case
P([]):

### Inductive Case

#### IH: 
