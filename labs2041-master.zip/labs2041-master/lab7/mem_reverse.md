# `mem e (reverse l) ≡ mem e l`

### Property
P(l):

### Base Case
P([]):

### Inductive Case

#### IH: 
