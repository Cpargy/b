1. `take 2 (squares 3)`
Choose Normal Form or Never
Put a value here, and/or an explanation

2. `fold_right (&&) (map ((<) 0) (squares 2)) true`
Choose Normal Form or Never
Put a value here, and/or an explanation

3. `fold_right (||)  (map (fun n -> n mod 3 = 0) (factorials ())) false`
Choose Normal Form or Never
Put a value here, and/or an explanation

4. `take (sum_list (squares 1)) (factorials ())`
Choose Normal Form or Never
Put a value here, and/or an explanation

5. `take 1 (reverse (squares 2))`
Choose Normal Form or Never
Put a value here, and/or an explanation

6. `fold_right (+) (take 1 (factorials ())) 0`
Choose Normal Form or Never
Put a value here, and/or an explanation

7. `(fun x -> if false then x else ()) (flip 0 0)`
Choose Normal Form or Never
Put a value here, and/or an explanation
